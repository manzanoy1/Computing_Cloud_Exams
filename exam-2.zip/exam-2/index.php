<!DOCTYPE html>
<html>
	<head>
		<title>Exam 2</title>
		<link href="css/myStyle.css" rel="stylesheet">
	</head>
	<body>
		<?php
			$h1 = '<h1>';
			$h1End = '</h1>';
			
			$divClass = 'exercise'; # one of the classes defined in CSS file, myStyle.css inside css folder.
			
			$tr = '<tr>'; # store <tr> tag inside $tr variable. <tr> indicates start of row in a table.
			$trEnd = '</tr>'; # store </tr> tag inside $trEnd variable. </tr> indicates end of a row in a table.
			
			$th = '<th>'; # table header
			$thEnd = '</th>'; # end of table header
			
			$td = "<td>"; # store <td> tag inside $td variable. <td> indicates start of a cell in a table.
			$tdEnd = "</td>"; # store </td> tag inside $tdEnd variable. </td> indicates end of a cell in a table.
			
			$table = "<table>"; # store <table> tag inside $table variable. <table> indicates start of a table in an HTML page.
			$tableEnd = "</table>"; # store </table> tag inside $tableEnd variable. </table> indicates end of a table in an HTML page.
			
			$div = "<div class=$divClass>"; # <div class='exercise'> indicates start of a new section that falls under 'exercise' class (CSS).
			$divEnd = "</div>"; # </div> indicates end of the section.
			
			$p = "<p>"; # <p> indicates start of a paragraph in an HTML page.
			$pEnd = "</p>"; # </p> indicates end of a paragraph in an HTML page.
			
			$lineBreak = '<br>'; # line break in HTML page.
			$lessThan = '&lt;'; # '<' symbol
			$greaterThan = '&gt;'; # '>' symbol
			
			$ol = '<ol>';
			$olEnd = '</ol>';
			
			$ul = '<ul>';
			$ulEnd = '</ul>';
			
			$li = '<li>';
			$liEnd = '</li>';
			
			$b = '<b>';
			$bEnd = '</b>';
			
			$maxPoints = 0;
			$problemCount = 0;
			
			$star = "&#10032;";
			
			print $div;
				print "$h1 Exam 2 $h1End";
			print $divEnd;
			
		?>
					
		<?php
			printProblemsToSolve('Create an array $myStates that stores at least 5 states that you have ever visited.', 10);
			
			# Code for Problem 1 Starts Here
			$Minnesota = "Minnesota";
			$Florida = "Florida";
			$NewYork = "New York";
			$WashingtonDC = "Washington D.C.";
			$Pennsylvania = "Pennsylvania";
			
			$myStates = array($Minnesota, $Florida, $NewYork, $WashingtonDC, $Pennsylvania);
			
			array_push($myStates);
			
			printProblemsToSolve("Print names of the states stored inside the array 
									you have created above (use a for or a foreach loop).", 10);
			
			# Code for Problem 2 Starts Here
			foreach($myStates as $item){
				print "$ol $star $item $olEnd";
			}
			
			print "$lineBreak $lineBreak";
			
			printProblemsToSolve("Push 5 more states to the list you have created above using array_push(...), sort them in descending order, and display them.", 20);
			
			# Code for Problem 3 Starts Here
			$Virginia = "Virginia";
			$NorthCarolina = "North Carolina";
			$SouthCarolina = "South Carolina";
			$NewJersey = "New Jersey";
			$Georgia = "Georgia";
			
			array_push($myStates, $Virginia, $NorthCarolina, $SouthCarolina, $NewJersey, $Georgia);
			rsort($myStates);
			foreach($myStates as $item){
				print "$ol $star $item $olEnd";
			}
			
			print "$lineBreak $lineBreak";
			
			printProblemsToSolve("Use a while loop to print numbers from 11 to 33.", 10);
			
			# Code for Problem 4 Starts Here
			$y = 11;
			while($y <= 33){
				print "$y ";
				$y++;
			}
			
			print "$lineBreak $lineBreak";
			
			
			printProblemsToSolve("Locate and make changes to function printTable() such that
									it will print a 10X10 table as shown in the sample webpage: ", 20);
			
			printTable();
			
			print $div;
				updateScore(30);
				print "$ol
						$li There should be no errors/warnings in your code (10 Points). $liEnd
						$li You should provide a full functioning AWS Elastic Beanstalk link (10 Points). $liEnd
						$li Upload zip file containing index.php and css folder on D2L. (10 Points). $liEnd
						$li Total Points: $b $maxPoints $bEnd $liEnd
					$olEnd
				";
			print $divEnd;
		?>
		
		<?php
		
			function printTable(){
				global $table, $tableEnd, $tr, $trEnd, $td, $tdEnd;
				
				# Your Code for Problem 5 Starts Here ... 
				# If you are not familiar with nested for loops, modify the sample below.
				
				# creating a sample table without using nested for loops.
				print $table; # printing <table>
					# printing HTML tag <tr> representing start of the first row
					print $tr;
						print "$td (0, 0) $tdEnd"; # printing cell at position (0, 0) First Row First and First Column
						print "$td (0, 1) $tdEnd"; # printing cell at position (0, 1) First Row First and Second Column
						print "$td (0, 2) $tdEnd"; # printing cell at position (0, 2) First Row First and Third Column
						print "$td (0, 3) $tdEnd"; # printing cell at position (0, 3) First Row First and Fourth Column
						print "$td (0, 4) $tdEnd";
						print "$td (0, 5) $tdEnd";
						print "$td (0, 6) $tdEnd";
						print "$td (0, 7) $tdEnd";
						print "$td (0, 8) $tdEnd";
						print "$td (0, 9) $tdEnd";
					print $trEnd; # printing HTML tag </tr> representing end of first row
					
					# second row
					print $tr;
						print "$td (1, 0) $tdEnd"; # printing cell at position (1, 0) Second Row First and First Column
						print "$td (1, 1) $tdEnd"; # printing cell at position (1, 1) Second Row First and Second Column
						print "$td (1, 2) $tdEnd"; # printing cell at position (1, 2) Second Row First and Third Column
						print "$td (1, 3) $tdEnd"; # printing cell at position (1, 3) Second Row First and Fourth Column
						print "$td (1, 4) $tdEnd";
						print "$td (1, 5) $tdEnd";
						print "$td (1, 6) $tdEnd";
						print "$td (1, 7) $tdEnd";
						print "$td (1, 8) $tdEnd";
						print "$td (1, 9) $tdEnd";
					print $trEnd; # printing HTML tag </tr> representing end of second row
					
					#third row
					print $tr;
						print "$td (2, 0) $tdEnd"; 
						print "$td (2, 1) $tdEnd";
						print "$td (2, 2) $tdEnd"; 
						print "$td (2, 3) $tdEnd"; 
						print "$td (2, 4) $tdEnd";
						print "$td (2, 5) $tdEnd";
						print "$td (2, 6) $tdEnd";
						print "$td (2, 7) $tdEnd";
						print "$td (2, 8) $tdEnd";
						print "$td (2, 9) $tdEnd";
					print $trEnd;
					
					#fourth row
					print $tr;
						print "$td (3, 0) $tdEnd"; 
						print "$td (3, 1) $tdEnd";
						print "$td (3, 2) $tdEnd"; 
						print "$td (3, 3) $tdEnd"; 
						print "$td (3, 4) $tdEnd";
						print "$td (3, 5) $tdEnd";
						print "$td (3, 6) $tdEnd";
						print "$td (3, 7) $tdEnd";
						print "$td (3, 8) $tdEnd";
						print "$td (3, 9) $tdEnd";
					print $trEnd;
					
					#fifth row
					print $tr;
						print "$td (4, 0) $tdEnd"; 
						print "$td (4, 1) $tdEnd";
						print "$td (4, 2) $tdEnd"; 
						print "$td (4, 3) $tdEnd"; 
						print "$td (4, 4) $tdEnd";
						print "$td (4, 5) $tdEnd";
						print "$td (4, 6) $tdEnd";
						print "$td (4, 7) $tdEnd";
						print "$td (4, 8) $tdEnd";
						print "$td (4, 9) $tdEnd";
					print $trEnd;
					
					#sixth row
					print $tr;
						print "$td (5, 0) $tdEnd"; 
						print "$td (5, 1) $tdEnd";
						print "$td (5, 2) $tdEnd"; 
						print "$td (5, 3) $tdEnd"; 
						print "$td (5, 4) $tdEnd";
						print "$td (5, 5) $tdEnd";
						print "$td (5, 6) $tdEnd";
						print "$td (5, 7) $tdEnd";
						print "$td (5, 8) $tdEnd";
						print "$td (5, 9) $tdEnd";
					print $trEnd;
					
					#seventh row
					print $tr;
						print "$td (6, 0) $tdEnd"; 
						print "$td (6, 1) $tdEnd";
						print "$td (6, 2) $tdEnd"; 
						print "$td (6, 3) $tdEnd"; 
						print "$td (6, 4) $tdEnd";
						print "$td (6, 5) $tdEnd";
						print "$td (6, 6) $tdEnd";
						print "$td (6, 7) $tdEnd";
						print "$td (6, 8) $tdEnd";
						print "$td (6, 9) $tdEnd";
					print $trEnd;
					
					#eigth row
					print $tr;
						print "$td (7, 0) $tdEnd"; 
						print "$td (7, 1) $tdEnd";
						print "$td (7, 2) $tdEnd"; 
						print "$td (7, 3) $tdEnd"; 
						print "$td (7, 4) $tdEnd";
						print "$td (7, 5) $tdEnd";
						print "$td (7, 6) $tdEnd";
						print "$td (7, 7) $tdEnd";
						print "$td (7, 8) $tdEnd";
						print "$td (7, 9) $tdEnd";
					print $trEnd;
					
					#nineth row
					print $tr;
						print "$td (8, 0) $tdEnd"; 
						print "$td (8, 1) $tdEnd";
						print "$td (8, 2) $tdEnd"; 
						print "$td (8, 3) $tdEnd"; 
						print "$td (8, 4) $tdEnd";
						print "$td (8, 5) $tdEnd";
						print "$td (8, 6) $tdEnd";
						print "$td (8, 7) $tdEnd";
						print "$td (8, 8) $tdEnd";
						print "$td (8, 9) $tdEnd";
					print $trEnd;
					
					#tenth row
					print $tr;
						print "$td (9, 0) $tdEnd"; 
						print "$td (9, 1) $tdEnd";
						print "$td (9, 2) $tdEnd"; 
						print "$td (9, 3) $tdEnd"; 
						print "$td (9, 4) $tdEnd";
						print "$td (9, 5) $tdEnd";
						print "$td (9, 6) $tdEnd";
						print "$td (9, 7) $tdEnd";
						print "$td (9, 8) $tdEnd";
						print "$td (9, 9) $tdEnd";
					print $trEnd;
					# Please add more columns and more rows to complete this problem. Please update the comments accordingly.
				print $tableEnd; # printing </table> representing end of the table in HTML.
				
			}
			
			# MODIFICATION PROHIBITED AFTER THIS LINE
			
			function printItemLists($myArray){
				global $div, $divEnd, $star;
				print $div;				
					foreach($myArray as $item){
						print "$star $item ";
					}
				print $divEnd;
			}
			
			function printExamples($description){
				global $div, $divEnd, $p, $pEnd, $listOfFruits, $example_counter;
				++$example_counter;
				print $div;
					print "$p Example $example_counter: $description. $pEnd";
					printItemLists($listOfFruits);
				print $divEnd;
			}
			
			function printProblemsToSolve($problem_description, $points){
				global $div, $divEnd, $p, $pEnd, $maxPoints, $problemCount;
				++$problemCount;
				print $div;
					print "$p Problem $problemCount: $problem_description ($points Points) $pEnd";
					updateScore($points);
				print $divEnd;
			}
			
			function updateScore($score){
				global $maxPoints;
				$maxPoints += $score;
			}
		?>
	</body>
</html>