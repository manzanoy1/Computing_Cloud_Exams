<!DOCTYPE html>
<html>
	<head>
		<title>Exam 1</title>
		<link href="css/myStyle.css" rel="stylesheet">
	</head>
	<body>
		<?php
			$h1 = '<h1>';
			$h1End = '</h1>';
			
			print "$h1 Exam 1 - Display Hartwick Logos $h1End";
			
			$divClass = 'exercise'; # one of the classes defined in CSS file, myStyle.css inside css folder.
			
			$x = 10;
			$y = 7;
			
			$tr = '<tr>'; # store <tr> tag inside $tr variable. <tr> indicates start of row in a table.
			$trEnd = '</tr>'; # store </tr> tag inside $trEnd variable. </tr> indicates end of a row in a table.
			
			$td = "<td>"; # store <td> tag inside $td variable. <td> indicates start of a cell in a table.
			$tdEnd = "</td>"; # store </td> tag inside $tdEnd variable. </td> indicates end of a cell in a table.
			
			$table = "<table>"; # store <table> tag inside $table variable. <table> indicates start of a table in an HTML page.
			$tableEnd = "</table>"; # store </table> tag inside $tableEnd variable. </table> indicates end of a table in an HTML page.
			
			$div = "<div class=$divClass>"; # <div class='exercise'> indicates start of a new section that falls under 'exercise' class (CSS).
			$divEnd = "</div>"; # </div> indicates end of the section.
			
			$p = "<p>"; # <p> indicates start of a paragraph in an HTML page.
			$pEnd = "</p>"; # </p> indicates end of a paragraph in an HTML page.
			
			$lineBreak = '<br>'; # line break in HTML page.
			$lessThan = '&lt;'; # '<' symbol
			$greaterThan = '&gt;'; # '>' symbol
			
			$imageList = array('Hartwick_Logo_1.png', 
								'Hartwick_Logo_2.png', 
								'Hartwick_Logo_3.jpg',
								'Hartwick_Logo_4.jpg',
								'Hartwick_Logo_5.png',
								'Hartwick_Logo_6.png'
								);
			$index = mt_rand(0, count($imageList) - 1);
			print $div;
				print $p;
					print "<img src=images/$imageList[$index] alt='Hartwick Logo'>";
				print $pEnd;
			print $divEnd;
			
			header("refresh: 3");
		
		?>
	</body>
</html>